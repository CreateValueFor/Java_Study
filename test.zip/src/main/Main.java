
public class Main
{
	public static void main(String[] args)
	{
		Sorter sorter = new Sorter();
		
		int[] asc = sorter.ascending(new int[] {1, 2, 3});
		
		System.out.println("Hello, world\n");
	}
}