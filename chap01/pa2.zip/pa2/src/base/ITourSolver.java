public interface ITourSolver {
    int[] solve(Board board);
}
